![welcome](https://i.ibb.co/tcFW9Yz/58aff1cf829958a978a4a6cb.png)

### 📩 Join us here: [https://t.me/drainerservices](https://t.me/drainerservices)

----
## ⚫ Solana Wallet Drainer & NFT Stealer Template

![@cryptodrainers](https://cdn.discordapp.com/attachments/975346579215122494/979836524529057832/unknown.png)
----

## 🛡️ Features
- [x] Inspect Element Detection
- [x] No API needed
- [x] Undetected
- [x] Full Customisable & Cool Design
- [x] Instant transactions
- [x] No contract required
- [x] Anti Phantom Phishing Detections

## ✏️ Setup Guide
You need to edit the **files/main.chunk.js** file to change the solana receiver wallet.

- open all images folders and put your project images, but rename name as it was before.
- open index.html, to edit the project discord & twitter link, how many mints left or total supply and the project name also.

After it, you're done. You only need to host the website into Netlify for example or Hostinger

To get instant support, contact me on [Telegram](https://t.me/alcapone_services)


## 🌊 Socials

- Telegram Group: https://t.me/drainerservices
- Shop: https://alcxpone.sellix.io
